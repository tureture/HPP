#define G 144

void print_pyramid(int pyramidSize);
