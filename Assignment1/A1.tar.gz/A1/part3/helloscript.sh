echo Hej hej
echo Hej igen
